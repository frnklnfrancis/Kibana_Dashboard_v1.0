import {Component} from '@angular/core';

/**
 * @title Configurable progress spinner
 */
@Component({
  selector: 'progress-spinner-configurable',
  templateUrl: 'progress-spinner-component.html',
  styleUrls: ['progress-spinner-component.css']
})
export class ProgressSpinnerConfigurable {
  color = 'primary';
  mode = 'determinate';
  value = 50;
}
