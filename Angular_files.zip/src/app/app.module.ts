import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app.routing';
import { MatCardModule,MatInputModule,MatFormFieldModule,MatButtonModule,MatSidenavModule,
  MatToolbarModule,MatCheckboxModule,MatButtonToggleModule,MatIconModule,MatTooltipModule } from '@angular/material';
import { AppComponent } from './app.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { DashboardComponent } from './dashboard/dashboard.component';
import {ProgressSpinnerConfigurable} from './shared-component/progress-spinner-component/progress-spinner-component';
// const appRoutes: Routes = [
// ];

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    ProgressSpinnerConfigurable
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    RouterModule,
    // RouterModule.forRoot(
    //   appRoutes,
    //   { enableTracing: true } // <-- debugging purposes only
    // )
    FormsModule,MatCardModule,MatFormFieldModule,MatInputModule,
    ReactiveFormsModule,MatButtonModule,
    MatSidenavModule,MatToolbarModule,MatCheckboxModule,MatButtonToggleModule,
    MatIconModule,MatTooltipModule,MatProgressSpinnerModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
