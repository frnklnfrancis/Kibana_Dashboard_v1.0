import { Component } from '@angular/core';
// import {LoginComponent} from './login.component';
// import {PrivateComponent} from './private.component';
import {Router} from '@angular/router';
import {FormBuilder, FormGroup} from '@angular/forms';
import {ProgressSpinnerConfigurable} from './shared-component/progress-spinner-component/progress-spinner-component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  options: FormGroup;
  title = 'Your Device Info!';
  showFiller = true;
  showLabel =false;
  loading:boolean=false;
  constructor(fb: FormBuilder,private router: Router) {
    this.options = fb.group({
      'fixed': false,
      'top': 0,
      'bottom': 0
    });
    this.loading = true;    
  }
  randomName(start: any) {
    this.showFiller = true;
    if(document.getElementById('sidenavwidth').style.width == '50px'){
    document.getElementById('sidenavwidth').style.width = "150px";
    document.getElementById('sidenavwidth').style.transition='width 1s ease-in-out';
    document.getElementById('sidenavwidth').style.overflow='hidden';
    this.showLabel = true;
    }else{
      document.getElementById('sidenavwidth').style.width = "50px";
      document.getElementById('sidenavwidth').style.transition='width 1s ease-in-out';
      this.showLabel = false;
    }
    //start.toggle();
}
  redirectrul(url){
    this.loading= false;
    this.router.navigate(['./'+url]);
    //routerLink='/dashboard'
  }
  
  setsliderwidth(){
  if(this.showFiller==true){
    return "w50p";
  }  else{
    return "w200p";
  }
  }
  shouldRun = [/(^|\.)plnkr\.co$/, /(^|\.)stackblitz\.io$/].some(h => h.test(window.location.host));
  // navlog() {
  //   localStorage.removeItem("user");
  //   this._router.navigate(['login']);
  // }
}
