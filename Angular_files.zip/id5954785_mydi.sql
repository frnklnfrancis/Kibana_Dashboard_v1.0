-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 29, 2018 at 04:41 PM
-- Server version: 10.2.12-MariaDB
-- PHP Version: 7.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id5954785_mydi`
--

-- --------------------------------------------------------

--
-- Table structure for table `androiddetail`
--

CREATE TABLE `androiddetail` (
  `avid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `smid` bigint(20) NOT NULL,
  `version` varchar(10) NOT NULL,
  `os` varchar(25) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `appdetail`
--

CREATE TABLE `appdetail` (
  `appid` int(11) NOT NULL,
  `appname` varchar(45) NOT NULL,
  `releasedate` datetime NOT NULL,
  `charge` float NOT NULL,
  `status` tinyint(4) NOT NULL,
  `version` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `imeidetail`
--

CREATE TABLE `imeidetail` (
  `imid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `imeinumber` varchar(45) NOT NULL,
  `smid` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `locationdetail`
--

CREATE TABLE `locationdetail` (
  `locid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `smid` bigint(20) NOT NULL,
  `locationtype` varchar(10) NOT NULL,
  `logtitude` varchar(45) NOT NULL,
  `latitude` varchar(45) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logdetail`
--

CREATE TABLE `logdetail` (
  `lgid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `smid` bigint(20) NOT NULL,
  `table` varchar(45) NOT NULL,
  `columnname` varchar(45) NOT NULL,
  `vid` bigint(20) NOT NULL,
  `oldvalue` varchar(45) NOT NULL,
  `newvalue` varchar(45) NOT NULL,
  `type` varchar(1) NOT NULL,
  `logdate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mobilebasicdetail`
--

CREATE TABLE `mobilebasicdetail` (
  `mpbid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `smid` bigint(20) NOT NULL,
  `purchasedate` datetime NOT NULL,
  `documentpath` varchar(100) NOT NULL,
  `message` varchar(100) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `model` varchar(45) NOT NULL,
  `buildnumber` varchar(45) NOT NULL,
  `serialnumber` varchar(45) NOT NULL,
  `uptime` varchar(45) NOT NULL,
  `processor` varchar(45) NOT NULL,
  `ram` varchar(45) NOT NULL,
  `rom` varchar(45) NOT NULL,
  `securityquestionid` tinyint(4) NOT NULL,
  `securityanswer` varchar(45) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `networkdetail`
--

CREATE TABLE `networkdetail` (
  `ntid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `smid` bigint(20) NOT NULL,
  `networktype` varchar(45) NOT NULL,
  `value` varchar(45) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `partsdetail`
--

CREATE TABLE `partsdetail` (
  `ptid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `smid` bigint(20) NOT NULL,
  `partname` varchar(45) NOT NULL,
  `value` varchar(45) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `securityquestion`
--

CREATE TABLE `securityquestion` (
  `sqid` tinyint(4) NOT NULL,
  `squestion` varchar(500) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `simdetail`
--

CREATE TABLE `simdetail` (
  `smid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `simslot` tinyint(4) NOT NULL,
  `network` varchar(45) NOT NULL,
  `number` varchar(45) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userdetail`
--

CREATE TABLE `userdetail` (
  `uid` bigint(20) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cpassword` varchar(100) NOT NULL,
  `randnum` varchar(10) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetail`
--

INSERT INTO `userdetail` (`uid`, `emailid`, `name`, `password`, `cpassword`, `randnum`, `status`) VALUES
(1, 'shansu1990@gmail.com', 'Shanmuga Sundaram', '12345', '12345', '12345', 1),
(2, 'gcstvli@gmail.com', 'Ganapathy Computers', '54321', '54321', '54321', 1),
(3, 'karthikeyanm0822@gmail.com', 'Karthikeyan', '12345', '12345', '12345', 1),
(4, 'shansu2690@gmail.com', 'Shanmuga Sundaram', '54321', '54321', '54321', 0);

-- --------------------------------------------------------

--
-- Table structure for table `userdevice`
--

CREATE TABLE `userdevice` (
  `udid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `name` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `androiddetail`
--
ALTER TABLE `androiddetail`
  ADD PRIMARY KEY (`avid`);

--
-- Indexes for table `appdetail`
--
ALTER TABLE `appdetail`
  ADD PRIMARY KEY (`appid`);

--
-- Indexes for table `imeidetail`
--
ALTER TABLE `imeidetail`
  ADD PRIMARY KEY (`imid`);

--
-- Indexes for table `locationdetail`
--
ALTER TABLE `locationdetail`
  ADD PRIMARY KEY (`locid`);

--
-- Indexes for table `logdetail`
--
ALTER TABLE `logdetail`
  ADD PRIMARY KEY (`lgid`);

--
-- Indexes for table `mobilebasicdetail`
--
ALTER TABLE `mobilebasicdetail`
  ADD PRIMARY KEY (`mpbid`);

--
-- Indexes for table `networkdetail`
--
ALTER TABLE `networkdetail`
  ADD PRIMARY KEY (`ntid`);

--
-- Indexes for table `partsdetail`
--
ALTER TABLE `partsdetail`
  ADD PRIMARY KEY (`ptid`);

--
-- Indexes for table `securityquestion`
--
ALTER TABLE `securityquestion`
  ADD PRIMARY KEY (`sqid`),
  ADD UNIQUE KEY `squestion_UNIQUE` (`squestion`);

--
-- Indexes for table `simdetail`
--
ALTER TABLE `simdetail`
  ADD PRIMARY KEY (`smid`);

--
-- Indexes for table `userdetail`
--
ALTER TABLE `userdetail`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `emailid_UNIQUE` (`emailid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `userdetail`
--
ALTER TABLE `userdetail`
  MODIFY `uid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
